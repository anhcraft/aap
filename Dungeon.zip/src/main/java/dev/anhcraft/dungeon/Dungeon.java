package dev.anhcraft.dungeon;

import io.lumine.xikage.mythicmobs.api.bukkit.events.MythicMobDeathEvent;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public final class Dungeon extends JavaPlugin implements Listener {
    private final Map<Player, Party> playerParties = new HashMap<>();
    private File dataFile;
    private FileConfiguration data;

    public List<String> getUnlockedRegions(Player player) {
        return data.getStringList(player.getUniqueId().toString() + ".regions");
    }

    public void unlockRegion(Player player, String region) {
        Set<String> set = new HashSet<>(getUnlockedRegions(player));
        set.add(region);
        data.set(player.getUniqueId().toString() + ".regions", new ArrayList<>(set));
    }

    public void unlockRegion(Player player, Collection<String> regions) {
        Set<String> set = new HashSet<>(getUnlockedRegions(player));
        set.addAll(regions);
        data.set(player.getUniqueId().toString() + ".regions", new ArrayList<>(set));
    }

    @EventHandler
    public void join(PlayerJoinEvent event){
        if (!data.isSet(event.getPlayer().getUniqueId().toString())) {
            data.set(event.getPlayer().getUniqueId().toString() + ".regions", getConfig().getStringList("starting_region"));
        }
    }

    @EventHandler
    public void quit(PlayerQuitEvent event){
        Party p = playerParties.remove(event.getPlayer());
        if(p != null) {
            p.sendMsg(getConfig().getString("messages.member_quit").replace("{player}", event.getPlayer().getName()));
            if(p.getLeader().equals(event.getPlayer())) {
                p.sendMsg(getConfig().getString("messages.party_destroyed"));
                p.getMembers().forEach(playerParties::remove);
            }
        }
    }

    @EventHandler
    public void interact(PlayerInteractEvent event){
        if(event.hasBlock()) {
            Block b = event.getClickedBlock();
            if(b.getState() instanceof Sign) {
                Sign sign = (Sign) b.getState();
                String[] lines = sign.getLines();
                if(lines != null && lines.length >= 2 && lines[0].contains("Dungeon")){
                    if(event.getPlayer().isSneaking() && event.getPlayer().hasPermission("dungeon.break_sign")) {
                        return;
                    }
                    event.setCancelled(true);
                    String region = lines[1];
                    if(getConfig().isSet("regions." + region)) {
                        Party p = playerParties.get(event.getPlayer());
                        if(p != null) {
                            if(p.getLeader().equals(event.getPlayer())) {
                                if(!p.isInPve()) {
                                    if(p.getAvailableRegions().contains(region)) {
                                        p.setInPve(true);
                                        p.getRemainBoss().addAll(getConfig().getStringList("regions." + region + ".bosses"));
                                        p.setLastLocation(event.getPlayer().getLocation());
                                        p.setCallback(() -> {
                                            p.setInPve(false);
                                            p.sendMsg(getConfig().getString("messages.finished"));
                                            p.getMembers().forEach(player -> {
                                                unlockRegion(player, getConfig().getStringList("regions." + region + ".unlock_regions"));
                                                player.teleport(p.getLastLocation());
                                            });
                                        });
                                        Location location = LocationUtil.fromString(getConfig().getString("regions." + region + ".spawn"));
                                        p.getMembers().forEach(player -> player.teleport(location));
                                    } else {
                                        event.getPlayer().sendMessage(getConfig().getString("messages.region_locked"));
                                    }
                                } else {
                                    event.getPlayer().sendMessage(getConfig().getString("messages.party_playing"));
                                }
                            } else {
                                event.getPlayer().sendMessage(getConfig().getString("messages.member_not_leader"));
                            }
                        } else {
                            event.getPlayer().sendMessage(getConfig().getString("messages.party_not_exist"));
                        }
                    } else {
                        event.getPlayer().sendMessage(getConfig().getString("messages.region_not_found"));
                    }
                }
            }
        }
    }

    @EventHandler
    public void death(MythicMobDeathEvent event) {
        LivingEntity killer = event.getKiller();
        if(killer instanceof Player) {
            Party p = playerParties.get(killer);
            if(p != null && p.isInPve()) {
                p.getRemainBoss().remove(event.getMob().getType().getInternalName());
                p.sendMsg(getConfig().getString("messages.objective_remain").replace("{remain}", String.valueOf(p.getRemainBoss().size())));
                if(p.getRemainBoss().isEmpty()) {
                    p.getCallback().run();
                }
            }
        }
    }

    public static <T extends ConfigurationSection> T formatConfig(T section){
        Set<String> keys = section.getKeys(true);
        for(String key : keys){
            Object value = section.get(key);
            if(value instanceof String) {
                section.set(key, ChatColor.translateAlternateColorCodes('&', (String) value));
            } else if(value instanceof List) {
                section.set(key, ((List<?>) value).stream()
                        .map(s -> ChatColor.translateAlternateColorCodes('&', (String) s))
                        .collect(Collectors.toList()));
            }
        }
        return section;
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        reloadConfig();

        formatConfig(getConfig());

        dataFile = new File(getDataFolder(), "data.yml");
        try {
            dataFile.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            data = YamlConfiguration.loadConfiguration(dataFile);
        }

        getServer().getPluginManager().registerEvents(this, this);

        getCommand("dungeon").setExecutor((sender, command, label, args) -> {
            if(args.length > 0 && sender instanceof Player) {
                Player p = (Player) sender;
                switch (args[0].toLowerCase()) {
                    case "getloc": {
                        if(p.hasPermission("dungeon.getloc")) {
                            p.sendMessage(LocationUtil.toString(p.getLocation()));
                        }
                        return false;
                    }
                    case "reload": {
                        if(p.hasPermission("dungeon.reload")) {
                            reloadConfig();
                            formatConfig(getConfig());
                            p.sendMessage("config reloaded.");
                        }
                        return false;
                    }
                    case "create": {
                        if(!playerParties.containsKey(p)) {
                            Party party = new Party(p);
                            party.getAvailableRegions().addAll(getUnlockedRegions(p));
                            playerParties.put(p, party);
                            p.sendMessage(getConfig().getString("messages.party_created"));
                        } else {
                            p.sendMessage(getConfig().getString("messages.party_existed"));
                        }
                        return false;
                    }
                    case "add": {
                        if(args.length > 1) {
                            Party party = playerParties.get(p);
                            if(party != null) {
                                if(party.getLeader().equals(p)) {
                                    Player target = Bukkit.getPlayer(args[1]);
                                    if (target != null) {
                                        if(target.getName().equals(p.getName())) {
                                            p.sendMessage(getConfig().getString("messages.not_self"));
                                            return false;
                                        }
                                        Party targetParty = playerParties.get(target);
                                        if (targetParty == null) {
                                            party.getMembers().add(target);
                                            party.sendMsg(getConfig().getString("messages.member_join").replace("{player}", target.getName()));
                                            playerParties.put(target, party);
                                            List<String> list = getUnlockedRegions(target);
                                            party.getAvailableRegions().removeIf(s -> !list.contains(s));
                                        } else if(targetParty.equals(party)) {
                                            p.sendMessage(getConfig().getString("messages.party_existed_yours"));
                                        } else {
                                            p.sendMessage(getConfig().getString("messages.party_existed_other"));
                                        }
                                    } else {
                                        p.sendMessage(getConfig().getString("messages.player_not_found"));
                                    }
                                } else {
                                    p.sendMessage(getConfig().getString("messages.member_not_leader"));
                                }
                            } else {
                                p.sendMessage(getConfig().getString("messages.party_not_exist"));
                            }
                        } else {
                            p.sendMessage(getConfig().getString("messages.invalid_cmd"));
                        }
                        return false;
                    }
                    case "kick": {
                        if(args.length > 1) {
                            Party party = playerParties.get(p);
                            if(party != null) {
                                if(party.getLeader().equals(p)) {
                                    Player target = Bukkit.getPlayer(args[1]);
                                    if (target != null) {
                                        if(target.getName().equals(p.getName())) {
                                            p.sendMessage(getConfig().getString("messages.not_self"));
                                            return false;
                                        }
                                        Party targetParty = playerParties.get(target);
                                        if (targetParty == null || !targetParty.equals(party)) {
                                            p.sendMessage(getConfig().getString("messages.member_not_found"));
                                        } else {
                                            party.getMembers().remove(target);
                                            playerParties.remove(target);
                                            party.sendMsg(getConfig().getString("messages.member_quit").replace("{player}", args[1]));
                                        }
                                    } else {
                                        p.sendMessage(getConfig().getString("messages.player_not_found"));
                                    }
                                } else {
                                    p.sendMessage(getConfig().getString("messages.member_not_leader"));
                                }
                            } else {
                                p.sendMessage(getConfig().getString("messages.party_not_exist"));
                            }
                        } else {
                            p.sendMessage(getConfig().getString("messages.invalid_cmd"));
                        }
                        return false;
                    }
                    case "destroy": {
                        Party party = playerParties.get(p);
                        if(party != null) {
                            if(party.getLeader().equals(p)) {
                                party.sendMsg(getConfig().getString("messages.party_destroyed"));
                                party.getMembers().forEach(playerParties::remove);
                            } else {
                                p.sendMessage(getConfig().getString("messages.member_not_leader"));
                            }
                        } else {
                            p.sendMessage(getConfig().getString("messages.party_not_exist"));
                        }
                        return false;
                    }
                }
            }
            getConfig().getStringList("messages.commands").forEach(sender::sendMessage);
            return false;
        });

        new BukkitRunnable() {
            @Override
            public void run() {
                try {
                    data.save(dataFile);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.runTaskTimerAsynchronously(this, 0, 100);
    }

    @Override
    public void onDisable() {
        try {
            data.save(dataFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
