package dev.anhcraft.dungeon;

import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class Party {
    private final Player leader;
    private final List<String> remainBoss = new ArrayList<>();
    private final List<Player> members = new ArrayList<>();
    private final List<String> availableRegions = new ArrayList<>();
    private boolean inPve;
    private Runnable callback;
    private Location lastLocation;

    public Party(Player leader) {
        this.leader = leader;
        members.add(leader);
    }

    public Player getLeader() {
        return leader;
    }

    public List<String> getRemainBoss() {
        return remainBoss;
    }

    public List<Player> getMembers() {
        return members;
    }

    public boolean isInPve() {
        return inPve;
    }

    public void setInPve(boolean inPve) {
        this.inPve = inPve;
    }

    public void sendMsg(String msg) {
        members.forEach(m -> m.sendMessage(msg));
    }

    public Runnable getCallback() {
        return callback;
    }

    public void setCallback(Runnable callback) {
        this.callback = callback;
    }

    public List<String> getAvailableRegions() {
        return availableRegions;
    }

    public Location getLastLocation() {
        return lastLocation;
    }

    public void setLastLocation(Location lastLocation) {
        this.lastLocation = lastLocation;
    }
}
