Commands and permissions:
/agc: open the admin menu (agc.admin)
/agc reload: reload the plugin (agc.admin)

For players:
agc.open.*: allows players access all GUIs
agc.open.<id>: allows players access the GUI which has the given id

