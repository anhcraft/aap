package dev.anhcraft.nullairdrops;

import org.bukkit.Location;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class Airdrop {
    private String id;
    private final List<Location> locations = new ArrayList<>();
    private final List<ItemStack> itemStacks = new ArrayList<>();
    private long dropTime = 100;

    public Airdrop(String id) {
        this.id = id;
    }

    public List<ItemStack> getItemStacks() {
        return itemStacks;
    }

    public List<Location> getLocations() {
        return locations;
    }

    public String getId() {
        return id;
    }

    public long getDropTime() {
        return dropTime;
    }

    public void setDropTime(long dropTime) {
        this.dropTime = dropTime;
    }
}
