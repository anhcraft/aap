package dev.anhcraft.nullairdrops;

import net.md_5.bungee.api.ChatColor;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ThreadLocalRandom;

public final class NullAirdrops extends JavaPlugin {
    public final Map<String, Airdrop> DATA = new ConcurrentHashMap<>();
    private final File DATA_DIR = new File("plugins/NullAirdrops/data/");
    private final Queue<Airdrop> SAVE_QUEUE = new ConcurrentLinkedQueue<>();

    private void reload(){
        DATA.clear();
        Arrays.stream(Objects.requireNonNull(DATA_DIR.listFiles(File::isFile)))
                .map(YamlConfiguration::loadConfiguration).forEach(c -> {
            String u = c.getString("id");
            Airdrop x = new Airdrop(u);
            x.getLocations().addAll((Collection<? extends Location>) c.getList("locations"));
            x.getItemStacks().addAll((Collection<? extends ItemStack>) c.getList("items"));
            x.setDropTime(c.getLong("dropTime"));
            getLogger().info("Loaded airdrop "+u+" with "+x.getItemStacks().size()+" items ("+x.getLocations().size()+" positions)");
            DATA.put(u, x);
        });
    }

    private void save(Airdrop airdrop){
        YamlConfiguration c = new YamlConfiguration();
        c.set("id", airdrop.getId());
        c.set("locations", airdrop.getLocations());
        c.set("items", airdrop.getItemStacks());
        c.set("dropTime", airdrop.getDropTime());
        try {
            c.save(new File(DATA_DIR, airdrop.getId() + ".yml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void spawnAirdrop(Airdrop airdrop) {
        Location top = airdrop.getLocations().get(ThreadLocalRandom.current().nextInt(airdrop.getLocations().size()));
        Location x = top.clone();
        List<Location> locs = new LinkedList<>();
        while (!x.subtract(0, 1, 0).getBlock().getType().isSolid()) locs.add(x.clone());

        if(locs.isEmpty()) return;

        FireworkEffect fwe = FireworkEffect.builder().withColor(Color.AQUA).withColor(Color.LIME).withColor(Color.OLIVE).flicker(true).withTrail().withFade(Color.MAROON).withFade(Color.NAVY).withFade(Color.RED).build();
        ArmorStand as = top.getWorld().spawn(top, ArmorStand.class);
        as.setArms(false);
        as.setGravity(false);
        as.setHelmet(new ItemStack(Material.CHEST, 1));
        as.setBasePlate(false);
        as.setVisible(false);
        as.setCustomNameVisible(false);

        long c = 0;
        long f = airdrop.getDropTime()/locs.size();
        for(Location loc : locs){
            new BukkitRunnable() {
                @Override
                public void run() {
                    as.teleport(loc);
                    if(Math.random() < 0.2) {
                        Firework fw = top.getWorld().spawn(loc.clone().add(0, 1, 0), Firework.class);
                        FireworkMeta fm = fw.getFireworkMeta();
                        fm.addEffect(fwe);
                        fw.setFireworkMeta(fm);
                    }
                }
            }.runTaskLater(this, c += f);
        }

        Plugin plugin = this;
        new BukkitRunnable() {
            @Override
            public void run() {
                Location c = as.getLocation();
                as.remove();
                Block b = c.getBlock();
                b.setType(Material.CHEST);

                new BukkitRunnable() {
                    @Override
                    public void run() {
                        Inventory bi = ((Chest) b.getState()).getBlockInventory();
                        List<ItemStack> i = new ArrayList<>(airdrop.getItemStacks());
                        Collections.shuffle(i, new Random(c.getWorld().getSeed()));
                        i.stream().limit(bi.getSize()).forEach(bi::addItem);
                        b.getState().update(true);
                    }
                }.runTask(plugin);
            }
        }.runTaskLater(this, c + f);
    }

    @Override
    public void onEnable() {
        if(DATA_DIR.mkdirs()) getLogger().info("Đã tạo thư mục dữ liệu!");

        reload();

        getCommand("airdrop").setExecutor((sender, command, label, args) -> {
            if(!sender.hasPermission("airdrop.admin")){
                sender.sendMessage("Bạn không có quyền!");
                return false;
            }
            if(args.length == 0){
                sender.sendMessage(ChatColor.GREEN+"/airdrop: Nhận trợ giúp");
                sender.sendMessage(ChatColor.GREEN+"/airdrop list: Xem danh sách");
                sender.sendMessage(ChatColor.GREEN+"/airdrop create <id>: Tạo airdrop");
                sender.sendMessage(ChatColor.GREEN+"/airdrop additem <id>: Thêm vật phẩm đang cầm vào airdrop");
                sender.sendMessage(ChatColor.GREEN+"/airdrop remove <id>: Xóa airdrop");
                sender.sendMessage(ChatColor.GREEN+"/airdrop setdroptime <id> <ticks>: Chỉnh thời gian rớt của airdrop (đơn vị tick)");
                sender.sendMessage(ChatColor.GREEN+"/airdrop addlocation <id>: Lấy vị trí hiện tại làm nơi spawn airdrop");
                sender.sendMessage(ChatColor.GREEN+"/airdrop spawn <id>: Spawn airdrop");
                sender.sendMessage(ChatColor.GREEN+"/airdrop reload: Nạp lại config");
            } else {
                switch (args[0]) {
                    case "list":
                        sender.sendMessage(String.join(", ", DATA.keySet()));
                        break;
                    case "create":
                        if (args.length == 1) {
                            sender.sendMessage(ChatColor.GREEN+"/airdrop create <id>: Tạo airdrop");
                        } else {
                            Airdrop airdrop = new Airdrop(args[1]);
                            DATA.put(args[1], airdrop);
                            sender.sendMessage("Đã tạo");
                            if(!SAVE_QUEUE.contains(airdrop)) SAVE_QUEUE.offer(airdrop);
                        }
                        break;
                    case "additem":
                        if (args.length == 1) {
                            sender.sendMessage(ChatColor.GREEN+"/airdrop additem <id>: Thêm vật phẩm đang cầm vào airdrop");
                        } else if (sender instanceof Player) {
                            ItemStack item = ((Player) sender).getInventory().getItemInMainHand();
                            if (item == null || item.getType() == Material.AIR) {
                                sender.sendMessage("Vui lòng cầm item trong tay");
                            } else {
                                Airdrop airdrop = DATA.get(args[1]);
                                if (airdrop == null) {
                                    sender.sendMessage("Không tìm thấy airdrop!");
                                } else {
                                    airdrop.getItemStacks().add(item);
                                    sender.sendMessage("Đã thêm ~~~");
                                    if(!SAVE_QUEUE.contains(airdrop)) SAVE_QUEUE.offer(airdrop);
                                }
                            }
                        } else {
                            sender.sendMessage("Bạn chỉ có thể dùng lệnh này trong game");
                        }
                        break;
                    case "addlocation":
                        if (args.length == 1) {
                            sender.sendMessage(ChatColor.GREEN+"/airdrop addlocation <id>: Lấy vị trí hiện tại làm nơi spawn airdrop");
                        } else if (sender instanceof Player) {
                            Airdrop airdrop = DATA.get(args[1]);
                            if (airdrop == null) {
                                sender.sendMessage("Không tìm thấy airdrop!");
                            } else {
                                airdrop.getLocations().add(((Player) sender).getLocation().getBlock().getLocation());
                                sender.sendMessage("Đã thêm ~~~");
                                if(!SAVE_QUEUE.contains(airdrop)) SAVE_QUEUE.offer(airdrop);
                            }
                        } else {
                            sender.sendMessage("Bạn chỉ có thể dùng lệnh này trong game");
                        }
                        break;
                    case "setdroptime":
                        if (args.length <= 2) {
                            sender.sendMessage(ChatColor.GREEN+"/airdrop setdroptime <id> <ticks>: Chỉnh thời gian rớt của airdrop (đơn vị tick)");
                        } else if (args[2].matches("[0-9]+")) {
                            Airdrop airdrop = DATA.get(args[1]);
                            if (airdrop == null) {
                                sender.sendMessage("Không tìm thấy airdrop!");
                            } else {
                                airdrop.setDropTime(Long.parseLong(args[2]));
                                sender.sendMessage("Đã cập nhật ~~~");
                                if(!SAVE_QUEUE.contains(airdrop)) SAVE_QUEUE.offer(airdrop);
                            }
                        } else {
                            sender.sendMessage("Vui lòng dùng số! [0-9]");
                        }
                        break;
                    case "remove":
                        if (args.length == 1) {
                            sender.sendMessage(ChatColor.GREEN+"/airdrop remove <id>: Xóa airdrop");
                        } else {
                            Airdrop ad = DATA.remove(args[1]);
                            SAVE_QUEUE.remove(ad);
                            new File(DATA_DIR, ad.getId() + ".yml").delete();
                            sender.sendMessage("Đã xóa ~~~");
                        }
                        break;
                    case "spawn":
                        if (args.length == 1) {
                            sender.sendMessage(ChatColor.GREEN+"/airdrop spawn <id>: Spawn airdrop");
                        } else {
                            Airdrop airdrop = DATA.get(args[1]);
                            if (airdrop == null) {
                                sender.sendMessage("Không tìm thấy airdrop!");
                            } else {
                                spawnAirdrop(airdrop);
                            }
                        }
                        break;
                    case "reload":
                        reload();
                        sender.sendMessage("Đã reload!");
                        break;
                    default:
                        sender.sendMessage("Không tìm thấy lệnh! /airdrop để nhận trợ giúp");
                        break;
                }
            }
            return false;
        });

        getServer().getScheduler().runTaskTimerAsynchronously(this, () -> {
            Airdrop ad = SAVE_QUEUE.poll();
            if(ad != null) save(ad);
        }, 20,180);
    }
}
