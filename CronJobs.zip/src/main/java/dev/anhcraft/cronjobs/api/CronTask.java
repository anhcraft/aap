package dev.anhcraft.cronjobs.api;

import dev.anhcraft.cronjobs.CronJobs;
import dev.anhcraft.cronjobs.utils.TimeUnit;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.text.SimpleDateFormat;

public class CronTask {
    private String cmd;
    private boolean async;
    private long startTime;
    private long endTime;
    private long delayTime;
    private long repeatTime;
    private long maxDuration;
    private int maxRepeat;
    private int id = -1;
    private int repeatCounter = 0;
    private long durationCounter = 0L;

    public CronTask(String cmd, boolean async, long startTime, long endTime, long delayTime, long repeatTime, long maxDuration, int maxRepeat) {
        this.cmd = cmd;
        this.async = async;
        this.startTime = startTime;
        this.endTime = endTime;
        this.delayTime = delayTime;
        this.repeatTime = repeatTime;
        this.maxDuration = maxDuration;
        this.maxRepeat = maxRepeat;
    }

    public int getId() {
        return this.id;
    }

    public static CronTask parse(String c) throws Exception {
        var s1 = c.split("~");
        var t1 = new String[s1.length - 1];
        System.arraycopy(s1, 1, t1, 0, s1.length - 1);
        var s2 = s1[0].split(" ");
        var cmd = String.join("~", t1).trim();
        var has_to = false;
        var has_repeat = false;
        var has_from = false;
        var has_wait = false;
        var async = false;
        var start = System.currentTimeMillis();
        var delay = 0L;
        var repeat = -1L;
        var end = -1L;
        var max_repeat = 0;
        var max_duration = 0L;
        
        for (String x : s2) {
            String[] n;
            if (x.startsWith("@async")) async = true;
            else if (x.startsWith("@from:")) {
                has_from = true;
                n = x.substring("@from:".length()).split(",");
                var year = -1;
                var month = -1;
                var day = -1;
                var hour = 0;
                var minute = 0;
                var second = 0;
                String[] arrstring = n;
                for (String t : arrstring) {
                    int v = Integer.parseInt(t.substring(0, t.length() - 1));
                    if (t.endsWith("y")) year = v;
                    else if (t.endsWith("M")) month = v;
                    else if (t.endsWith("d")) day = v;
                    else if (t.endsWith("h")) hour = v;
                    else if (t.endsWith("m")) minute = v;
                    else if (t.endsWith("s")) second = v;
                }
                if (year == -1 || month == -1 || day == -1) throw new Exception("Thiếu các giá trị sau (year, month, day)");
                start = new SimpleDateFormat("yyyy MM dd HH mm ss").parse("" + year + " " + month + " " + day + " " + hour + " " + minute + " " + second).getTime();
            }
            else if (x.startsWith("@to:")) {
                has_to = true;
                n = x.substring("@to:".length()).split("\\),");
                for (String q : n) {
                    if (q.charAt(q.length() - 1) == ')') {
                        q = q.substring(0, q.length() - 1);
                    }
                    if (q.startsWith("repeat(")) {
                        max_repeat = Integer.parseInt(q.substring("repeat(".length()));
                    }
                    if (q.startsWith("duration(")) {
                        String[] j = q.substring("duration(".length()).split(",");
                        for (String t : j) {
                            if (t.endsWith("y")) max_duration = (long) (max_duration + Double.parseDouble(t.substring(0, t.length() - 1)) * TimeUnit.YEAR.getSeconds() * 20.0);
                            else if (t.endsWith("ly")) max_duration = (long)(max_duration + Double.parseDouble(t.substring(0, t.length() - 2)) * TimeUnit.LEAP_YEAR.getSeconds() * 20.0);
                            else if (t.endsWith("M")) max_duration = (long)(max_duration + Double.parseDouble(t.substring(0, t.length() - 1)) * TimeUnit.MONTH_30.getSeconds() * 20.0);
                            else if (t.endsWith("M30")) max_duration = (long)(max_duration + Double.parseDouble(t.substring(0, t.length() - 3)) * TimeUnit.MONTH_30.getSeconds() * 20.0);
                            else if (t.endsWith("M29")) max_duration = (long)(max_duration + Double.parseDouble(t.substring(0, t.length() - 3)) * TimeUnit.MONTH_29.getSeconds() * 20.0);
                            else if (t.endsWith("M28")) max_duration = (long)(max_duration + Double.parseDouble(t.substring(0, t.length() - 3)) * TimeUnit.MONTH_28.getSeconds() * 20.0);
                            else if (t.endsWith("M31")) max_duration = (long)(max_duration + Double.parseDouble(t.substring(0, t.length() - 3)) * TimeUnit.MONTH_31.getSeconds() * 20.0);
                            else if (t.endsWith("d")) max_duration = (long)(max_duration + Double.parseDouble(t.substring(0, t.length() - 1)) * TimeUnit.DAY.getSeconds() * 20.0);
                            else if (t.endsWith("h")) max_duration = (long)(max_duration + Double.parseDouble(t.substring(0, t.length() - 1)) * TimeUnit.HOUR.getSeconds() * 20.0);
                            else if (t.endsWith("m")) max_duration = (long)(max_duration + Double.parseDouble(t.substring(0, t.length() - 1)) * TimeUnit.MINUTE.getSeconds() * 20.0);
                            else if (t.endsWith("s")) max_duration = (long)(max_duration + Double.parseDouble(t.substring(0, t.length() - 1)) * 20.0);
                            else if (t.endsWith("w")) max_duration = (long)(max_duration + Double.parseDouble(t.substring(0, t.length() - 1)) * TimeUnit.WEEK.getSeconds() * 20.0);
                            else if (t.endsWith("ms")) max_duration = (long)(max_duration + Double.parseDouble(t.substring(0, t.length() - 1)) * TimeUnit.MILLISECOND.getSeconds() * 20.0);
                            else if (t.endsWith("t")) max_duration = (long)(max_duration + Double.parseDouble(t.substring(0, t.length() - 1)));
                        }
                    }
                    if (!q.startsWith("date(")) continue;
                    String[] j = q.substring("date(".length()).split(",");
                    var year = -1;
                    var month = -1;
                    var day = -1;
                    var hour = 0;
                    var minute = 0;
                    var second = 0;
                    for (String t : j) {
                        if (t.endsWith("y")) year = Integer.parseInt(t.substring(0, t.length() - 1));
                        else if (t.endsWith("M")) month = Integer.parseInt(t.substring(0, t.length() - 1));
                        else if (t.endsWith("d")) day = Integer.parseInt(t.substring(0, t.length() - 1));
                        else if (t.endsWith("h")) hour = Integer.parseInt(t.substring(0, t.length() - 1));
                        else if (t.endsWith("m")) minute = Integer.parseInt(t.substring(0, t.length() - 1));
                        else if (t.endsWith("s")) second = Integer.parseInt(t.substring(0, t.length() - 1));
                    }
                    if (year == -1 || month == -1 || day == -1) throw new Exception("Thiếu các giá trị sau (year, month, day)");
                    end = new SimpleDateFormat("yyyy MM dd HH mm ss").parse("" + year + " " + month + " " + day + " " + hour + " " + minute + " " + second).getTime();
                }
            }
            else if (x.startsWith("@wait:")) {
                has_wait = true;
                n = x.substring("@wait:".length()).split(",");
                for (String t : n) {
                    if (t.endsWith("y")) delay = (long)(delay + Double.parseDouble(t.substring(0, t.length() - 1)) * TimeUnit.YEAR.getSeconds() * 20.0);
                    else if (t.endsWith("ly")) delay = (long)(delay + Double.parseDouble(t.substring(0, t.length() - 2)) * TimeUnit.LEAP_YEAR.getSeconds() * 20.0);
                    else if (t.endsWith("M")) delay = (long)(delay + Double.parseDouble(t.substring(0, t.length() - 1)) * TimeUnit.MONTH_30.getSeconds() * 20.0);
                    else if (t.endsWith("M30")) delay = (long)(delay + Double.parseDouble(t.substring(0, t.length() - 3)) * TimeUnit.MONTH_30.getSeconds() * 20.0);
                    else if (t.endsWith("M29")) delay = (long)(delay + Double.parseDouble(t.substring(0, t.length() - 3)) * TimeUnit.MONTH_29.getSeconds() * 20.0);
                    else if (t.endsWith("M28")) delay = (long)(delay + Double.parseDouble(t.substring(0, t.length() - 3)) * TimeUnit.MONTH_28.getSeconds() * 20.0);
                    else if (t.endsWith("M31")) delay = (long)(delay + Double.parseDouble(t.substring(0, t.length() - 3)) * TimeUnit.MONTH_31.getSeconds() * 20.0);
                    else if (t.endsWith("d")) delay = (long)(delay + Double.parseDouble(t.substring(0, t.length() - 1)) * TimeUnit.DAY.getSeconds() * 20.0);
                    else if (t.endsWith("h")) delay = (long)(delay + Double.parseDouble(t.substring(0, t.length() - 1)) * TimeUnit.HOUR.getSeconds() * 20.0);
                    else if (t.endsWith("m")) delay = (long)(delay + Double.parseDouble(t.substring(0, t.length() - 1)) * TimeUnit.MINUTE.getSeconds() * 20.0);
                    else if (t.endsWith("s")) delay = (long)(delay + Double.parseDouble(t.substring(0, t.length() - 1)) * 20.0);
                    else if (t.endsWith("w")) delay = (long)(delay + Double.parseDouble(t.substring(0, t.length() - 1)) * TimeUnit.WEEK.getSeconds() * 20.0);
                    else if (t.endsWith("ms")) delay = (long)(delay + Double.parseDouble(t.substring(0, t.length() - 1)) * TimeUnit.MILLISECOND.getSeconds() * 20.0);
                    else if (!t.endsWith("t")) continue;
                    delay = (long)(delay + Double.parseDouble(t.substring(0, t.length() - 1)));
                }
            }
            else if (x.startsWith("@repeat:")) {
                has_repeat = true;
                n = x.substring("@repeat:".length()).split(",");
                for (String t : n) {
                    if (t.endsWith("y")) repeat = (long) (repeat + Double.parseDouble(t.substring(0, t.length() - 1)) * TimeUnit.YEAR.getSeconds() * 20.0);
                    else if (t.endsWith("ly")) repeat = (long) (repeat + Double.parseDouble(t.substring(0, t.length() - 2)) * TimeUnit.LEAP_YEAR.getSeconds() * 20.0);
                    else if (t.endsWith("M")) repeat = (long) (repeat + Double.parseDouble(t.substring(0, t.length() - 1)) * TimeUnit.MONTH_30.getSeconds() * 20.0);
                    else if (t.endsWith("M30")) repeat = (long) (repeat + Double.parseDouble(t.substring(0, t.length() - 3)) * TimeUnit.MONTH_30.getSeconds() * 20.0);
                    else if (t.endsWith("M29")) repeat = (long) (repeat + Double.parseDouble(t.substring(0, t.length() - 3)) * TimeUnit.MONTH_29.getSeconds() * 20.0);
                    else if (t.endsWith("M28")) repeat = (long) (repeat + Double.parseDouble(t.substring(0, t.length() - 3)) * TimeUnit.MONTH_28.getSeconds() * 20.0);
                    else if (t.endsWith("M31")) repeat = (long) (repeat + Double.parseDouble(t.substring(0, t.length() - 3)) * TimeUnit.MONTH_31.getSeconds() * 20.0);
                    else if (t.endsWith("d")) repeat = (long) (repeat + Double.parseDouble(t.substring(0, t.length() - 1)) * TimeUnit.DAY.getSeconds() * 20.0);
                    else if (t.endsWith("h")) repeat = (long) (repeat + Double.parseDouble(t.substring(0, t.length() - 1)) * TimeUnit.HOUR.getSeconds() * 20.0);
                    else if (t.endsWith("m")) repeat = (long) (repeat + Double.parseDouble(t.substring(0, t.length() - 1)) * TimeUnit.MINUTE.getSeconds() * 20.0);
                    else if (t.endsWith("s")) repeat = (long) (repeat + Double.parseDouble(t.substring(0, t.length() - 1)) * 20.0);
                    else if (t.endsWith("w")) repeat = (long) (repeat + Double.parseDouble(t.substring(0, t.length() - 1)) * TimeUnit.WEEK.getSeconds() * 20.0);
                    else if (t.endsWith("ms")) repeat = (long) (repeat + Double.parseDouble(t.substring(0, t.length() - 1)) * TimeUnit.MILLISECOND.getSeconds() * 20.0);
                    else if (t.endsWith("t")) repeat = (long) (repeat + Double.parseDouble(t.substring(0, t.length() - 1)));
                }
            }
        }
        if (has_to && !has_repeat) throw new Exception("@to chỉ có thể sử dụng với @repeat");
        if (has_from && has_wait)  throw new Exception("@from và @wait không thể sử dụng cùng lúc");
        return new CronTask(cmd, async, start, end, delay, repeat, max_duration, max_repeat);
    }

    public String getCmd() {
        return this.cmd;
    }

    public long getStartTime() {
        return this.startTime;
    }

    public long getEndTime() {
        return this.endTime;
    }

    public long getDelayTime() {
        return this.delayTime;
    }

    public long getRepeatTime() {
        return this.repeatTime;
    }

    public int getMaxRepeat() {
        return this.maxRepeat;
    }

    public long getMaxDuration() {
        return this.maxDuration;
    }

    public boolean isAsync() {
        return this.async;
    }

    public void start(final JavaPlugin plugin) {
        if (this.repeatTime == -1L) {
            var d = (this.startTime - System.currentTimeMillis()) / 50L;
            this.delayTime += Math.max(d, 0L);
            if (this.async) {
                this.id = new BukkitRunnable(){
                    public void run() {
                        plugin.getServer().dispatchCommand(plugin.getServer().getConsoleSender(), CronTask.this.cmd);
                    }
                }.runTaskLaterAsynchronously(plugin, this.delayTime).getTaskId();

                plugin.getServer().getConsoleSender().sendMessage(ChatColor.GREEN+"Đang chạy tác vụ trễ không đồng bộ #" + this.id);
            } else {
                this.id = new BukkitRunnable(){
                    public void run() {
                        plugin.getServer().dispatchCommand(plugin.getServer().getConsoleSender(), CronTask.this.cmd);
                    }
                }.runTaskLater(plugin, this.delayTime).getTaskId();

                plugin.getServer().getConsoleSender().sendMessage(ChatColor.GREEN+"Đang chạy tác vụ trễ đồng bộ #" + this.id);
            }
        } else {
            var d = (this.startTime - System.currentTimeMillis()) / 50L;
            this.delayTime += Math.max(d, 0L);
            if (this.async) {
                this.id = new BukkitRunnable(){
                    public void run() {
                        if (CronTask.this.endTime != -1L && System.currentTimeMillis() >= CronTask.this.endTime) {
                            plugin.getServer().getConsoleSender().sendMessage(ChatColor.GOLD+"Đang dừng "+ChatColor.WHITE+"tác vụ #" + CronTask.this.id + " "+ChatColor.GOLD+"vì đã hết thời hạn");
                            CronTask.this.stop(true);
                            return;
                        }
                        if (CronTask.this.maxRepeat > 0 && CronTask.this.repeatCounter >= CronTask.this.maxRepeat) {
                            plugin.getServer().getConsoleSender().sendMessage(ChatColor.GOLD+"Đang dừng "+ChatColor.WHITE+"tác vụ #" + CronTask.this.id + " "+ChatColor.GOLD+"vì đạt hạn mức số lần lặp");
                            CronTask.this.stop(true);
                            return;
                        }
                        if (CronTask.this.maxDuration > 0L && CronTask.this.durationCounter >= CronTask.this.maxDuration) {
                            plugin.getServer().getConsoleSender().sendMessage(ChatColor.GOLD+"Đang dừng "+ChatColor.WHITE+"tác vụ #" + CronTask.this.id + " "+ChatColor.GOLD+"vì đạt hạn mức thời gian hoạt động");
                            CronTask.this.stop(true);
                            return;
                        }
                        plugin.getServer().dispatchCommand(plugin.getServer().getConsoleSender(), CronTask.this.cmd);
                        CronTask.this.repeatCounter++;
                        CronTask.this.durationCounter = CronTask.this.durationCounter + CronTask.this.repeatTime;
                    }
                }.runTaskTimerAsynchronously(plugin, this.delayTime, this.repeatTime).getTaskId();
                plugin.getServer().getConsoleSender().sendMessage(ChatColor.GREEN+"Đang chạy tác vụ định kỳ không đồng bộ #" + this.id);
            } else {
                this.id = new BukkitRunnable(){
                    public void run() {
                        if (CronTask.this.endTime != -1L && System.currentTimeMillis() >= CronTask.this.endTime) {
                            plugin.getServer().getConsoleSender().sendMessage(ChatColor.GOLD+"Đang dừng "+ChatColor.WHITE+"tác vụ #" + CronTask.this.id + " "+ChatColor.GOLD+"vì đã hết thời hạn");
                            CronTask.this.stop(true);
                            return;
                        }
                        if (CronTask.this.maxRepeat > 0 && CronTask.this.repeatCounter >= CronTask.this.maxRepeat) {
                            plugin.getServer().getConsoleSender().sendMessage(ChatColor.GOLD+"Đang dừng "+ChatColor.WHITE+"tác vụ #" + CronTask.this.id + " "+ChatColor.GOLD+"vì đạt hạn mức số lần lặp");
                            CronTask.this.stop(true);
                            return;
                        }
                        if (CronTask.this.maxDuration > 0L && CronTask.this.durationCounter >= CronTask.this.maxDuration) {
                            plugin.getServer().getConsoleSender().sendMessage(ChatColor.GOLD+"Đang dừng "+ChatColor.WHITE+"tác vụ #" + CronTask.this.id + " "+ChatColor.GOLD+"vì đạt hạn mức thời gian hoạt động");
                            CronTask.this.stop(true);
                            return;
                        }
                        plugin.getServer().dispatchCommand(plugin.getServer().getConsoleSender(), CronTask.this.cmd);
                        CronTask.this.repeatCounter++;
                        CronTask.this.durationCounter = CronTask.this.durationCounter + CronTask.this.repeatTime;
                    }
                }.runTaskTimer(plugin, this.delayTime, this.repeatTime).getTaskId();
                plugin.getServer().getConsoleSender().sendMessage(ChatColor.GREEN+"Đang chạy tác vụ định kỳ đồng bộ #" + this.id);
            }
        }
    }

    public void stop(boolean remove) {
        if (this.id != -1) {
            Bukkit.getServer().getScheduler().cancelTask(this.id);
            this.id = -1;
            this.repeatCounter = 0;
            this.durationCounter = 0L;
            if (remove) CronJobs.tasks.remove(this);
        }
    }
}

