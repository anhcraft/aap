package dev.anhcraft.cronjobs;

import dev.anhcraft.cronjobs.api.CronTask;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.function.Consumer;

public final class CronJobs extends JavaPlugin implements CommandExecutor {
    public static final List<CronTask> tasks = new ArrayList<>();
    private static CronJobs pl;
    private static File f;

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args){
        if(sender.hasPermission("cronjobs.admin")){
            if(args.length == 0){
                sender.sendMessage(ChatColor.GREEN+"Danh sách tác vụ:");
                CronJobs.tasks.forEach(cronTask -> {
                    sender.sendMessage(ChatColor.AQUA+"#" + cronTask.getId() + " "+ChatColor.GOLD+"(" + (cronTask.isAsync() ? "KHÔNG ĐỒNG BỘ" : "ĐỒNG BỘ") + "):");
                    sender.sendMessage(ChatColor.WHITE+"- Lệnh: "+ChatColor.GRAY + cronTask.getCmd());

                    sender.sendMessage(ChatColor.WHITE+"- Thời điểm bắt đầu: "+ChatColor.GRAY + cronTask.getStartTime() + " (" + new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date(cronTask.getStartTime())) + ")");
                    if (cronTask.getEndTime() != -1L) sender.sendMessage(ChatColor.WHITE+"- Thời điểm kết thúc: "+ChatColor.GRAY + cronTask.getEndTime() + " (" + new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date(cronTask.getEndTime())) + ")");

                    sender.sendMessage(ChatColor.WHITE+"- Thời gian trễ: "+ChatColor.GRAY + cronTask.getDelayTime() + " tick");
                    if (cronTask.getRepeatTime() != -1L) sender.sendMessage(ChatColor.WHITE+"- Thời gian lặp: "+ChatColor.GRAY + cronTask.getRepeatTime() + " tick");
                    sender.sendMessage(ChatColor.WHITE+"- Mức lặp tối đa: "+ChatColor.GRAY + cronTask.getMaxRepeat() + " lần");

                    sender.sendMessage(ChatColor.WHITE+"- Khoảng thời gian tối đa: "+ChatColor.GRAY + cronTask.getMaxDuration() + " tick");
                });
            } else if(args[0].equals("reload")) {
                sender.sendMessage(ChatColor.GREEN+"Đang dừng các tác vụ...");
                synchronized (CronJobs.tasks) {
                    CronJobs.tasks.forEach(cronTask -> cronTask.stop(false));
                    CronJobs.tasks.clear();
                }
                sender.sendMessage(ChatColor.GREEN+"Đang nạp lại cấu hình...");
                reload();
                sender.sendMessage(ChatColor.GREEN+"Đã khởi động lại hệ thống!");
            } else if(args[0].equals("bc")) {
                getServer().broadcastMessage(ChatColor.translateAlternateColorCodes('&', String.join(" ", Arrays.copyOfRange(args, 1, args.length))));
            } else if(args.length > 1) {
                if(args[0].equals("fca")) {
                    var s = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
                    getServer().getOnlinePlayers().forEach((Consumer<Player>) player -> player.performCommand(s));
                } else if(args[0].equals("fc")) {
                    var p = getServer().getPlayer(args[1]);
                    if (p != null) p.performCommand(String.join(" ", Arrays.copyOfRange(args, 2, args.length)));
                }
            }
        } else {
            sender.sendMessage(ChatColor.RED+"Bạn không có quyền");
        }
        return true;
    }
    
    public void onEnable() {
        pl = this;
        f = new File(getDataFolder(), "config.txt");
        getDataFolder().mkdir();
        if(!f.exists()) {
            try {
                f.createNewFile();
                var t = new FileOutputStream(f);
                Objects.requireNonNull(getResource("config.txt")).transferTo(t);
                t.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        getServer().getScheduler().runTaskAsynchronously(this, this::reload);

        Objects.requireNonNull(getCommand("cj")).setExecutor(this);
    }

    private void reload() {
        synchronized (tasks) {
            try {
                var scanner = new Scanner(f);
                while (scanner.hasNextLine()){
                    var s = scanner.nextLine();
                    if (s.trim().length() == 0) continue;
                    if(s.startsWith("#")) continue;
                    try {
                        CronTask task = CronTask.parse(s);
                        if (task.getCmd().length() == 0) continue;
                        task.start(pl);
                        tasks.add(task);
                    }
                    catch (Exception e) {
                        this.getLogger().warning("Xảy ra lỗi với lệnh:");
                        this.getLogger().warning(s);
                        e.printStackTrace();
                    }
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    public void onDisable() {
        tasks.forEach(cronTask -> cronTask.stop(false));
        tasks.clear();
    }
}
